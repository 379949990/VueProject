<template>
  <main id="main-box">
    <header id="header">cart header</header>
    <div id="content">cart qwe</div>
  </main>
</template>
