<template>
  <main id="main-box">
    <header id="header">user header</header>
    <div id="content">user qwe</div>
  </main>
</template>
