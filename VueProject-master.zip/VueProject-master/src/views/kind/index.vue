<template>
  <main id="main-box">
    <header id="header">kind header</header>
    <div id="content">kind qwe</div>
  </main>
</template>
